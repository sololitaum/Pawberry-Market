import SpriteKit

class FrozenSection: SKScene {
    
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        
        // Set up background
        let background = SKSpriteNode(imageNamed: "Shelf")
        background.size = self.size
        background.position = CGPoint(x: self.size.width / 2, y: self.size.height / 2)
        self.addChild(background)
        background.zPosition = -1  // Ensure the background is behind other elements
        
        // Create a "Back" button using SKLabelNode
        let backButton = SKLabelNode(text: "Back to Game")
        backButton.fontName = "Arial"
        backButton.fontSize = 36
        backButton.fontColor = .white
        backButton.position = CGPoint(x: self.size.width / 2, y: self.size.height / 4)  // Position at bottom center
        backButton.name = "backButton"  // Assign a name for touch detection
        self.addChild(backButton)
        
        // Add separate sprites (2 Chickens + 1 Fish)
        addFrozenItems()
    }
    
    func addFrozenItems() {
        let chickenTexture = SKTexture(imageNamed: "chicken")  // Ensure "Chicken" is in Assets
        let fishTexture = SKTexture(imageNamed: "fish")        // Ensure "Fish" is in Assets
        
        let middleX = self.size.width / 2
        let middleY = self.size.height / 2
        let spacing: CGFloat = 200 // Distance between items

        // Left Chicken
        let chicken1 = SKSpriteNode(texture: chickenTexture)
        chicken1.size = CGSize(width: 150, height: 150)
        chicken1.position = CGPoint(x: middleX - spacing, y: middleY + 50)
        chicken1.name = "chicken"
        self.addChild(chicken1)

        // Middle Fish
        let fish = SKSpriteNode(texture: fishTexture)
        fish.size = CGSize(width: 150, height: 150)
        fish.position = CGPoint(x: middleX, y: middleY + 50)
        fish.name = "fish"
        self.addChild(fish)

        // Right Chicken
        let chicken2 = SKSpriteNode(texture: chickenTexture)
        chicken2.size = CGSize(width: 150, height: 150)
        chicken2.position = CGPoint(x: middleX + spacing, y: middleY + 50)
        chicken2.name = "chicken"
        self.addChild(chicken2)
    }
    
    // Detect touches
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let touchLocation = touch.location(in: self)
            let node = atPoint(touchLocation)
            
            // Check if the back button was tapped
            if let labelNode = node as? SKLabelNode, labelNode.name == "backButton" {
                transitionBackToGameScene()
                return
            }
            
            // Check if a food item was tapped and remove it
            if let spriteNode = node as? SKSpriteNode, spriteNode.name == "chicken" || spriteNode.name == "fish" {
                spriteNode.removeFromParent()  // Remove from scene
                // Add to an array??
            }
        }
    }
    
    // Function to transition back to GameScene
    func transitionBackToGameScene() {
        if let gameScene = GameScene(fileNamed: "GameScene") {
            gameScene.scaleMode = .aspectFill
            self.view?.presentScene(gameScene, transition: SKTransition.fade(withDuration: 0.5))
        }
    }
}

